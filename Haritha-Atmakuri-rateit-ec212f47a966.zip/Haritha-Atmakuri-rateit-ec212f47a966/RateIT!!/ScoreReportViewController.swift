//
//  ScoreReportViewController.swift
//  RateIT!!
//
//  Created by Student on 3/10/19.
//  Copyright © 2019 student. All rights reserved.
//

import UIKit

class ScoreReportViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource{
    
    
    var today = Date()
    
    let pickerView1 = UIPickerView()
    let pickerView2 = UIPickerView()
    let pickerView3 = UIPickerView()
    let pickerView4 = UIPickerView()
   
    
    @IBOutlet weak var vendorUTF: UITextField!
    @IBOutlet weak var ratingTF: UITextField!
    @IBOutlet weak var monthTF: UITextField!
    @IBOutlet weak var commentsTF: UITextField!
    @IBOutlet weak var yearTF: UITextField!
    
    var vendorsinscore:[String]?
    var rating:[Double] = [0,1,1.5,2,2.5,3,3.5,4,4.5,5]
    
    var getTotalVendor:[Vendor] = Vendors.vendors.getVendors()
    var feedbackMonths:[String]=[]
    var feedbackYear:[String]=[]
    var selectedVendor:Vendor?
    var selectedFeedback:Score?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ratingTF.isEnabled = false
        //vendorsinscore = Vendors.vendors.getAllVendors()
        pickerView1.delegate = self
        pickerView2.delegate = self
        pickerView3.delegate = self
        pickerView4.delegate = self
        pickerView1.tag = 1
        pickerView2.tag = 2
        pickerView3.tag = 3
        pickerView4.tag = 4
        pickerView1.dataSource = self
        pickerView2.dataSource = self
        pickerView3.dataSource = self
        pickerView4.dataSource = self
        self.vendorUTF.inputView = self.pickerView1;
        self.ratingTF.inputView = self.pickerView2;
        self.monthTF.inputView = self.pickerView3;
        self.yearTF.inputView = self.pickerView4;
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if pickerView.tag == 1 {
            return vendorsinscore!.count
        } else if pickerView.tag == 2 {
            return rating.count
        } else if pickerView.tag == 3 {
            return  feedbackMonths.count
        }
        else if  pickerView.tag == 4 {
           return 1
        }
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        print(pickerView.tag)
        if pickerView.tag == 1 {
            return vendorsinscore![row]
        } else if pickerView.tag == 2 {
            return "\(rating[row])"
        } else if pickerView.tag == 3 {
            return feedbackMonths[row]
        }
        else if pickerView.tag == 4 {
            return "\(today.description.split(separator: " ")[0].split(separator: "-").map({Int($0)!})[0])"
        }
        return ""
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)  {
        if pickerView.tag == 1 {
            vendorUTF.text = vendorsinscore![row]
            //logic selectedVendor
            selectedVendor = Vendors.vendors.vendor(row)
            let date = today.description.split(separator: " ")[0].split(separator: "-")
            if Int(date[1])! > 2
            {
            feedbackMonths.append("\(months[Int(date[1])!-2])")
            feedbackMonths.append("\(months[Int(date[1])!-3])")
            }
            else if Int(date[1])! == 2
            {
                feedbackMonths.append("\(months[Int(date[1])!-2])")
                feedbackMonths.append("\(months[11])")
            }
            else
            {
                feedbackMonths.append("\(months[10])")
                feedbackMonths.append("\(months[11])")
            }
            //feedbackMonths.append("\(months[Int(date[1])!-2]) \(date[0])")
            //feedbackMonths.append("\(months[Int(date[1])!-3]) \(date[0])")
        } else if pickerView.tag == 2 {
            //ratingTF.isEnabled = true
            ratingTF.text = "\(rating[row])"
        }
        else if pickerView.tag == 3 {
        monthTF.text = feedbackMonths[row]
        }
        else if pickerView.tag == 4 {
            yearTF.text = "\(today.description.split(separator: " ")[0].split(separator: "-").map({Int($0)!})[0])"
             //yearTF.text = "\(today.description.split(separator: " ")[0].split(separator: "-").map({Int($0)!})[0])"
            //logic to find if any previous feedback if exists assign to selectedFeedback else nil
            for j in 0..<selectedVendor!.feedbacks.count{
                if selectedVendor!.feedbacks[j].month == monthTF.text! && selectedVendor!.feedbacks[j].year == Int(yearTF.text!){
                    selectedFeedback = selectedVendor!.feedbacks[j]
                    ratingTF.text = "\(selectedFeedback!.rating)"
                }
                else{
                    selectedFeedback = nil
                    ratingTF.text = ""
                }
            }
            ratingTF.isEnabled = true
        }
    }

    @IBAction func submit(_ sender: Any) {
        if selectedFeedback != nil{
            selectedFeedback?.update(score:Score(month: monthTF.text!, year: Int(yearTF.text!)!, rating: Double(ratingTF.text!)!, comments: commentsTF.text!))
            
            let alert = UIAlertController(title: "Success Page",
                                          message: "Your details have been succesfully added",
                                          preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default,
                                          handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
            else {
            selectedVendor?.feedbacks.append(Score(month: monthTF.text!, year: Int(yearTF.text!)!, rating: Double(ratingTF.text!)!, comments: commentsTF.text!))
            let alert = UIAlertController(title: "Success Page",
                                          message: "Your details have been succesfully added",
                                          preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default,
                                          handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    
}


}
