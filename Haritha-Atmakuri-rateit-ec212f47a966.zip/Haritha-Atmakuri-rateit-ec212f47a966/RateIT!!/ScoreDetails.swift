//
//  ScoreDetails.swift
//  RateIT!!
//
//  Created by student on 4/3/19.
//  Copyright © 2019 student. All rights reserved.
//

import Foundation
class Score : CustomStringConvertible, Equatable {
    var month:String
    var year:Int
    var rating:Double
    var comments:String
    
    init(month:String,year:Int,rating:Double,comments:String){
        self.month = month
        self.year = year
        self.rating = rating
        self.comments = comments
    }
    // Equatable protocol method lets us to compare 2 scores using the == operator
    static func == (lhs: Score, rhs: Score) -> Bool {
        return lhs.month == rhs.month
    }
    
    // When we try and print a score month instance, it will show whatever is returned by description
    var description: String {
        return "\(month)"
    }
    
     func update(score:Score){
        self.rating = score.rating
        self.comments = score.comments
    }
}

var months = ["January", "February", "March", "April", "May", "June", "July", "August"]

