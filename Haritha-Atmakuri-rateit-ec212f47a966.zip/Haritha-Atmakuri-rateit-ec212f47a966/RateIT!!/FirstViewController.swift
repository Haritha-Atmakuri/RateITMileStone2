//
//  FirstViewController.swift
//  RateIT!!
//
//  Created by student on 2/25/19.
//  Copyright © 2019 student. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var warningMessage: UILabel!
    @IBOutlet weak var userNameTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "loginPages"{
            
            if userNameTF.text == "" || passwordTF.text  == "" || userNameTF == nil || passwordTF == nil
            {
                let alert = UIAlertController(title: "Invalid Value",
                                              message: "Please enter valid login credentials",
                                              preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default,
                                              handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            else
            {
            return LoginCredentials.shared.checkCredentials(uname: userNameTF.text!, pwd: passwordTF.text!)
            }
        }
        return true
    }
    
}

