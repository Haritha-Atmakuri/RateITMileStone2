//
//  LoginDetails.swift
//  RateIT!!
//
//  Created by Student on 3/11/19.
//  Copyright © 2019 student. All rights reserved.
//

import Foundation

struct Login : CustomStringConvertible, Equatable {
    var loginID:String
    var password:String
    var role:String
    // Equatable protocol method lets us to compare 2 restaurants using the == operator
    static func == (lhs: Login, rhs: Login) -> Bool {
        return lhs.loginID == rhs.loginID && lhs.password == rhs.password
    }
    
    // When we try and print a Restaurant instance, it will show whatever is returned by description
    var description: String {
        return "\(role)"
    }
}

struct LoginCredentials {
    
    static var shared = LoginCredentials()
    var loggedUser:Login!
    private var loginList:[Login] = [
        Login(loginID: "admin", password: "admin123", role: "ADMIN"),
        Login(loginID: "vendor1", password: "vendor1", role: "VENDOR"),
        Login(loginID: "vendor2", password: "vendor2", role: "VENDOR")
        ]
  
    mutating func checkCredentials(uname:String,pwd:String) -> Bool
    {
       for i in 0..<loginList.count
       {
            print(loginList[i].loginID == uname, loginList[i].password == pwd)
            if loginList[i].loginID == uname && loginList[i].password == pwd
            {
                loggedUser = loginList[i]
                return true
            }
        }
        return false
    }
    
    mutating func add(login:Login){
        loginList.append(login)
    }
    
    mutating func delete(login:Login){
        for i in 0 ..< loginList.count {
            if loginList[i] == login {
                loginList.remove(at:i)
                break
            }
        }
        
    }
}

