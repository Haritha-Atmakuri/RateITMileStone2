//
//  AdminLoginViewController.swift
//  RateIT!!
//
//  Created by Student on 3/10/19.
//  Copyright © 2019 student. All rights reserved.
//

import UIKit

class AdminLoginViewController: UIViewController {

    @IBOutlet weak var scoreReport: UIButton!
    @IBOutlet weak var viewReport: UIButton!
    override func viewDidLoad() {
        if LoginCredentials.shared.loggedUser.role == "VENDOR"
        {
            scoreReport.isEnabled = false
            viewReport.isEnabled = true
        }
        else
        {
            scoreReport.isEnabled = true
            viewReport.isEnabled = true
        }
        super.viewDidLoad()
     
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        
        if segue.identifier == "scorereport" {
            let viewscore = segue.destination as! ScoreReportViewController
            // Pass the selected object to the new view controller.
            viewscore.vendorsinscore = Vendors.vendors.getAllVendors()
            print("Inside Scorer port")
        }
        else if segue.identifier == "viewreport" {
            let report = segue.destination as! GenerateReportViewController
            // Pass the selected object to the new view controller.
            report.generateReport = Vendors.vendors.getAllVendors()
        }
        
    }
    
  

}
