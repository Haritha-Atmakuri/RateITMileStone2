//
//  VendorsList.swift
//  RateIT!!
//
//  Created by Student on 3/10/19.
//  Copyright © 2019 student. All rights reserved.
//

import Foundation

class Vendor : CustomStringConvertible, Equatable {
    var Vname:String
    var feedbacks:[Score]
    
    init(Vname:String,feedbacks:[Score]){
        self.Vname = Vname
        self.feedbacks = []
    }
    
    // Equatable protocol method lets us to compare 2 restaurants using the == operator
    static func == (lhs: Vendor, rhs: Vendor) -> Bool {
        return lhs.Vname == rhs.Vname
    }
    
    // When we try and print a Restaurant instance, it will show whatever is returned by description
    var description: String {
        return "\(Vname)"
    }
}

class Vendors {
    
    static var vendors = Vendors()
    
    private var vendorList:[Vendor] = [
        Vendor(Vname: "A", feedbacks: []),
        Vendor(Vname: "B", feedbacks: []),
        Vendor(Vname: "C", feedbacks: []),
        Vendor(Vname: "D", feedbacks: []),
        Vendor(Vname: "E", feedbacks: []),
        Vendor(Vname: "F", feedbacks: []),
        ]
    init(vendorList:[Vendor]){
        self.vendorList = []
    }
    private init(){}
    
    func numRestaurants()->Int {
        return vendorList.count
    }
    
    func vendor(_ index:Int) -> Vendor {
        return vendorList[index]
    }
    
    // this lets us use [ ] notation instead of the above
    
    subscript(index:Int) -> Vendor {
        return vendorList[index]
    }
    
     func add(vendor:Vendor){
        vendorList.append(vendor)
    }
    
    func getVendors() -> [Vendor]
    {
        return vendorList
    }
     func getAllVendors() -> [String]
    {
        var vlist:[String] = []
        for i in 0..<vendorList.count
        {
            vlist.append(vendorList[i].Vname)
        }
       return vlist
    }
     func delete(vendor:Vendor){
        for i in 0 ..< vendorList.count {
            if vendorList[i] == vendor {
                vendorList.remove(at:i)
                break
            }
        }
        
    }
}

