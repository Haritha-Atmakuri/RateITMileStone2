//
//  singletonRateIt.swift
//  RateIT!!
//
//  Created by Paudel,Saroj on 3/11/19.
//  Copyright © 2019 student. All rights reserved.
//

import Foundation
class rateItManager{
    private init() {}
    static let shared = rateItManager()
    public func launch(){
        adminLaunch()
        guestLaunch()
    }
    private func adminLaunch(){
        
    }
    private func guestLaunch(){
        
    }
}
