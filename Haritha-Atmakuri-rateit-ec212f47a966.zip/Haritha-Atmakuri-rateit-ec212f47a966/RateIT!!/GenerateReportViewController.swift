//
//  GenerateReportViewController.swift
//  RateIT!!
//
//  Created by Student on 3/11/19.
//  Copyright © 2019 student. All rights reserved.
//

import UIKit

class GenerateReportViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    var today = Date()
    
    let pickerView1 = UIPickerView()
    let pickerView2 = UIPickerView()
    let pickerView3 = UIPickerView()
    
    @IBOutlet weak var vendorUTF: UITextField!
    @IBOutlet weak var monthsTF: UITextField!
    @IBOutlet weak var yearsTF: UITextField!
    @IBOutlet weak var showRating: UILabel!
    var generateReport:[String]?
    var feedbackMonths:[String]=[]
    var selectedVendor:Vendor?
    var obtainedRating:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pickerView1.delegate = self
        pickerView2.delegate = self
        pickerView3.delegate = self
        pickerView1.tag = 1
        pickerView2.tag = 2
        pickerView3.tag = 3
        pickerView1.dataSource = self
        pickerView2.dataSource = self
        pickerView3.dataSource = self
        self.vendorUTF.inputView = self.pickerView1;
        self.monthsTF.inputView = self.pickerView2;
        self.yearsTF.inputView = self.pickerView3;
        // Do any additional setup after loading the view.
    }
    

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if pickerView.tag == 1 {
            return generateReport!.count
        } else if pickerView.tag == 2 {
            return feedbackMonths.count
        } else if pickerView.tag == 3 {
            return  1
        }
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        print(pickerView.tag)
        if pickerView.tag == 1 {
            return generateReport![row]
        } else if pickerView.tag == 2 {
            return feedbackMonths[row]
        }
        else if pickerView.tag == 3{
            return "\(today.description.split(separator: " ")[0].split(separator: "-").map({Int($0)!})[0])"
        }
        return ""
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)  {
        if pickerView.tag == 1 {
            vendorUTF.text = generateReport![row]
            //logic selectedVendor
            selectedVendor = Vendors.vendors.vendor(row)
            let date = today.description.split(separator: " ")[0].split(separator: "-")
            if Int(date[1])! > 2
            {
                feedbackMonths.append("\(months[Int(date[1])!-2])")
                feedbackMonths.append("\(months[Int(date[1])!-3])")
            }
            else if Int(date[1])! == 2
            {
                feedbackMonths.append("\(months[Int(date[1])!-2])")
                feedbackMonths.append("\(months[11])")
            }
            else
            {
                feedbackMonths.append("\(months[10])")
                feedbackMonths.append("\(months[11])")
            }
            //feedbackMonths.append("\(months[Int(date[1])!-2]) \(date[0])")
            //feedbackMonths.append("\(months[Int(date[1])!-3]) \(date[0])")
        }
        else if pickerView.tag == 2 {
            monthsTF.text = feedbackMonths[row]
        }
        else if pickerView.tag == 3 {
            yearsTF.text = "\(today.description.split(separator: " ")[0].split(separator: "-").map({Int($0)!})[0])"
            //logic to find if any previous feedback if exists assign to selectedFeedback else nil
            for j in 0..<selectedVendor!.feedbacks.count{
                if selectedVendor!.feedbacks[j].month == monthsTF.text! && selectedVendor!.feedbacks[j].year == Int(yearsTF.text!){
                    obtainedRating = "\(String(describing: selectedVendor?.feedbacks[j].rating))"
                }
                else{
                    obtainedRating = nil
                }
            }
        }
        
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func generate(_ sender: Any) {
        if obtainedRating == nil
        {
            let alert = UIAlertController(title: "Error Page",
                                          message: "There are no details with this combination",
                                          preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default,
                                          handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else
        {
            showRating.text = "Your rating is:\(String(describing: obtainedRating))"
        }
    }
}

